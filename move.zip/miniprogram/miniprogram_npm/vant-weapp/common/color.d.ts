export declare const RED = "#f44";
export declare const BLUE = "#1989fa";
export declare const GREEN = "#07c160";
